var mainApp = (function () {
    'use strict';
    var apps = {};
    //var mirs_apiUrl = 'https://mirs.dev.finra.org/dblookup/meta';
    //var userID = 'cboe_user';
    var isUserInfoAvailable = false;
    apps.app = angular.module('cboeApp', ['ui.router', 'ngTouch','ngAnimate', 'ngMessages', 'ngMaterial', 'ui.bootstrap',
        'angular-loading-bar', 'angularjs-dropdown-multiselect', 'uiSwitch', 'uiSlider', 'ui.grid','ui.grid.grouping',
        'ngStorage','ui.grid.selection', 'ui.grid.exporter','ui.grid.moveColumns','ui.grid.autoResize','ui.grid.pagination',
        'ui.grid.resizeColumns','ui.grid.expandable','ui.grid.pinning','textAngular','nvd3','highcharts-ng']);

    console.log('inside mainApp');

    apps.app.config(['$stateProvider', '$urlRouterProvider','$animateProvider', '$mdThemingProvider',function ($stateProvider, $urlRouterProvider, $animateProvider, $mdThemingProvider) {
        //$urlRouterProvider.otherwise("/");
        //$urlRouterProvider.otherwise("/");
        $urlRouterProvider
            .when('', '/')
        $stateProvider
        // route for the home page
            .state('coreHome', {
                url: '/',
                templateUrl: 'domains/core/views/vw_home.html',
                controller: 'mainController'
            })
            // route for the core pages
            .state('coreViews', {
                url: '/core/:id',
                templateUrl: function (urlAttr) {
                    return 'domains/core/views/vw_' + urlAttr.id + '.html';
                },
                controller: 'mainController'
            })

            // route for the reports
            .state('domainViews', {
                url: '/:domain/:id',
                templateUrl: function (urlAttr) {
                    return 'domains/' + urlAttr.domain + '/views/vw_' + urlAttr.id + '.html';
                },
                controller: 'ReportController'
            });
        $animateProvider.classNameFilter(/^((?!(ui-grid-menu)).)*$/);
        $mdThemingProvider.theme('default').primaryPalette('blue',{'default': '800'}).accentPalette('deep-purple');

    }]);
    apps.app.run(function($rootScope,$http, $location, $state) {
        $rootScope._ = window._;
        $rootScope.userInfo = {};
        $rootScope.userInfo.info = [];
        $rootScope.userInfo.id = 'defaultUser';
        $rootScope.isAccessDenied = false;
        //$rootScope.isDomainAllowed = '';
        $rootScope.allowedDomains = ["equities","core", "options"];
        $rootScope.domainNameFromUrl = ''
        $http.get('/dblookup/meta/userInfo').then(function(response){
            $rootScope.userInfo = response.data;
            console.log($rootScope.userInfo)
            var hs = $rootScope.userInfo.info;
            console.log( hs)
            for (var i = 0; i < hs.length; i++) {
                var rep = {
                    id: hs[i].report_id,
                    title: 'recent -- ' + hs[i].report_id + hs[i].subbmitted_ts + hs[i].display_string,
                    params: JSON.parse(hs[i].params_json),
                    domain: 'cboe'
                };
                $rootScope.combined_domain_reports_list.push(rep);
            }
            return $rootScope.userInfo;
        }, function() {console.log('failed to retrieve userInfo')});

        $http.get('/dblookup/meta/headerInfo').then (function(response) {
            $rootScope.allowedDomains = ["equities","core", "options"];
            $rootScope.headerInfo = response.data;
            var roles = $rootScope.headerInfo.memberof;
            var rolesSplittedInArray = roles.split(",")
            var re = /^CN=[\s\S]*$/;
            var filtered = _.map(rolesSplittedInArray,function(i){if(re.test(i)){return i}});
            var onlyCNRoles = _.filter(filtered,function(n){return n!=undefined});
            //var onlyCNRoles = ["CN=ISSO_D_MIRS_NY_TFCE","CN=ISSO_D_MIRS_NY_OPTIONS", "CN=ISSO_D_MIRS_FI","CN=SVN_Users", "CN=PRIV_Beta_AppStore", "CN=DVSVC_MIRS_QC_INSTALL_ENGINEER", "CN=ISSO_D_RAW_READER", "CN=PPL_LOB_TEC", "CN=ISSO_Q_RAW_READER", "CN=APP_AppSense_Hostfile", "CN=DVSVC_WIAT_QC_INSTALL_ENGINEER", "CN=DVSVC_DTSVS_DEV_INSTALL_ENGINEER", "CN=PVSN_Lync_AV_Enabled", "CN=ISSO_D_MIRS", "CN=ISSO_D_DOM", "CN=DVSVC_PULSE_DEV_INSTALL_ENGINEER", "CN=PPL_DEPT_69940_KW", "CN=DVSVC_MIRS_DEV_INSTALL_ENGINEER", "CN=DVSVC_WIAT_DEV_INSTALL_ENGINEER", "CN=PRIV_BYOD_Approved", "CN=DVSVC_CBOERPT_DEV_INSTALL_ENGINEER", "CN=PPL_TEC_ALL_Developers", "CN=DVSVC_CBOERPT_READONLY", "CN=priv_sslvpn_default", "CN=DVSVC_RDAT_DEV_INSTALL_ENGINEER", "CN=CTX_PROD__Core_Applications", "CN=GPO_Outlook2010_ReadOnly_PSTs", "CN=ISSO_Q_MRDT_USERS", "CN=CTX_PROD_Remote_Desktop", "CN=DVSVC_RDAT_QC_INSTALL_ENGINEER", "CN=ISSO_Q_MIRS", "CN=PVSN_Lync"];
            var mirsRoles = [
                "CN=ISSO_D_MIRS_ADMIN","CN=ISSO_D_MIRS_NY_OPTIONS", "CN=ISSO_D_MIRS_TFCE", "CN=ISSO_D_MIRS_TA","CN=ISSO_D_MIRS_FI","CN=ISSO_D_MIRS_CBOE",
                "CN=ISSO_Q_MIRS_ADMIN","CN=ISSO_Q_MIRS_NY_OPTIONS", "CN=ISSO_Q_MIRS_TFCE", "CN=ISSO_Q_MIRS_FI", "CN=ISSO_Q_MIRS_CBOE", "ISSO_Q_MIRS_TA",
                "CN=ISSO_P_MIRS_ADMIN","CN=ISSO_P_MIRS_NY_OPTIONS", "CN=ISSO_P_MIRS_TFCE", "CN=ISSO_P_MIRS_CBOE", "ISSO_P_MIRS_TA", "CN=ISSO_P_MIRS_FI"
            ];
            $rootScope.allowedRoles = _.intersection(onlyCNRoles, mirsRoles)
            $rootScope.newAllowedDomains = [];
            if(window.location.href.indexOf("dev")>=0 || window.location.href.indexOf("int")>=0) {
                $rootScope.allowedRoles = _.filter( $rootScope.allowedRoles, function (role) {
                    return role.indexOf("ISSO_D_MIRS")>=0;
                })
            } else if (window.location.href.indexOf("qa")>=0) {
                $rootScope.allowedRoles = _.filter( $rootScope.allowedRoles, function (role) {
                    return role.indexOf("ISSO_Q_MIRS")>=0;
                })
            } else if (window.location.href.indexOf("mirs.finra.org")>=0) {
                $rootScope.allowedRoles = _.filter( $rootScope.allowedRoles, function (role) {
                    return role.indexOf("ISSO_P_MIRS")>=0;
                })
            };
            $rootScope.newAllowedDomains = _.map($rootScope.allowedRoles,function(str) {
                if(str.toLowerCase().indexOf("admin")>=0){return "admin"};
                if(str.toLowerCase().indexOf("options")>=0){return "options"};
                if(str.toLowerCase().indexOf("tfce")>=0){return "tfce"};
                if(str.toLowerCase().indexOf("ta")>=0){return "ta"};
                if(str.toLowerCase().indexOf("cboe")>=0){return "cboe"};
                if(str.toLowerCase().indexOf("fi")>=0){return "fi"};
                if(str.toLowerCase().indexOf("equities")>=0){return "equities"} else { return "equities"};
            });

            //if allowedRoles has Admin then grant all mirs roles
            if($rootScope.newAllowedDomains.includes('admin')) {
                $rootScope.newAllowedDomains = [];
                $rootScope.newAllowedDomains.push("equities","core","tfce", "ta", "fi", "options", "cboe");
            }

            console.log($rootScope.allowedDomains)
            $rootScope.allowedDomains = $rootScope.allowedDomains.concat($rootScope.newAllowedDomains)
            console.log($rootScope.allowedDomains)
            console.log($rootScope.allowedRoles);
            $rootScope.disable_ny_opts = true;
            $rootScope.disable_cboe = true;
            $rootScope.disable_tfce = true;
            $rootScope.disable_ta = true;
            $rootScope.disable_fi = true;
            _.map($rootScope.allowedRoles,function(role) {
                /*if (role === "CN=ISSO_D_MIRS_NY_OPTIONS"
                 || role === "CN=ISSO_Q_MIRS_NY_OPTIONS"
                 || role === "CN=ISSO_P_MIRS_NY_OPTIONS") {$rootScope.disable_ny_opts = false;};*/
                if (role === "CN=ISSO_D_MIRS_CBOE"
                    || role === "CN=ISSO_Q_MIRS_CBOE"
                    || role === "CN=ISSO_P_MIRS_CBOE") {$rootScope.disable_cboe = false;};
                if (role === "CN=ISSO_D_MIRS_TFCE"
                    || role === "CN=ISSO_Q_MIRS_TFCE"
                    || role === "CN=ISSO_P_MIRS_TFCE") {$rootScope.disable_tfce = false;};
                if (role === "CN=ISSO_D_MIRS_TA"
                    || role === "CN=ISSO_Q_MIRS_TA"
                    || role === "CN=ISSO_P_MIRS_TA") {$rootScope.disable_ta = false;}
                if (role === "CN=ISSO_D_MIRS_FI"
                    || role === "CN=ISSO_Q_MIRS_FI"
                    || role === "CN=ISSO_P_MIRS_FI") {$rootScope.disable_fi = false;}
                if (role === "CN=ISSO_D_MIRS_ADMIN"
                    || role === "CN=ISSO_Q_MIRS_ADMIN"
                    || role === "CN=ISSO_P_MIRS_ADMIN") {
                    $rootScope.disable_fi = false;$rootScope.disable_ny_opts = false;
                    $rootScope.disable_cboe = false;$rootScope.disable_tfce = false;
                    $rootScope.disable_ta = false;$rootScope.disable_fi = false;
                }
            })
        }, function() {
            $rootScope.allowedDomains=[];
            $rootScope.allowedDomains.push("equities","core", "options", "tfce");
            $rootScope.disable_cboe = true;
            $rootScope.disable_fi = true;
            $rootScope.disable_ny_opts = true;
            $rootScope.disable_ta = true;
            $rootScope.disable_tfce = true;
        })
        $rootScope.$on('$stateChangeStart', function(event, toState, fromState, toParams) {
            /*function confirmExit()
             {
             window.location.href='index.html';
             return true;
             }
             window.onbeforeunload = confirmExit;*/
            var path = $location.path();
            $rootScope.domainNameFromUrl = path.split('/')[1];
            $rootScope.allowedDomains.push($rootScope.domainNameFromUrl);
            /*if ($rootScope.allowedDomains.length == 0) {
             $rootScope.isDomainAllowed = false;
             } else*/ if ($rootScope.allowedDomains != undefined && $rootScope.allowedDomains.length != 0 ) {
                $rootScope.isDomainAllowed = _.includes($rootScope.allowedDomains, $rootScope.domainNameFromUrl)
            }  else {
                $rootScope.isDomainAllowed = true;
            }
            if (!$rootScope.isDomainAllowed && $rootScope.domainNameFromUrl !='') {
                $rootScope.isAccessDenied = true;
                $location.path('/core/home');
            } else if($rootScope.allowedDomains != undefined && $rootScope.domainNameFromUrl == '') {
                $rootScope.isAccessDenied = false;
                $location.path();
            } else if ($rootScope.allowedDomains.length == 0) {
                $rootScope.isDomainAllowed = false;
            }
            //$rootScope.isAccessDenied = false;
        })
        $http.get("/dblookup/mirs_common_api/trade_dts").then(function(response) {
            var tradeDates = response.data;
            $rootScope.globalMinDate = new Date(tradeDates[0].trade_dt);
            $rootScope.globalMaxDate = new Date(tradeDates[tradeDates.length-1].trade_dt);
            $rootScope.enableOnlyTradeDates = function(date) {
                for(var i=0;i<tradeDates.length;i++){
                    var tradeDate = new Date(tradeDates[i].trade_dt);
                    if(date.getUTCDate() === tradeDate.getUTCDate() && date.getUTCMonth() === tradeDate.getUTCMonth() && date. getUTCFullYear() === tradeDate. getUTCFullYear()){
                        return true;
                    }
                }
                return false;
            };
        });
    });

    apps.app.controller('mainController', function ($rootScope, $scope, $http, $location, $localStorage, $stateParams, $filter) {
        console.log($rootScope.userInfo)
        $scope._ = _;
        console.log($rootScope.allowedDomains)
        $rootScope.current_report = {};
        $rootScope.current_report.domain = 'core';
        $rootScope.current_report.id = 'home';
        $rootScope.isHTMLformat = false;
        $rootScope.isGridData = false;
        $rootScope.isFirstAnalyzerReport = false;
        $rootScope.isSecondAnalyzerReport = false;
        $rootScope.isThirdAnalyzerReport = false;
        $scope.selectedPerspective = 'Reports';
        $scope.searchPerspective = 'Reports'
        $scope.onPerspectiveChange = function(e) {
            if($scope.selectedPerspective == 'Reports') {
                $scope.searchPerspective = 'Reports'
            } else if ($scope.selectedPerspective == 'Recent') {
                $scope.searchPerspective = 'Recent'
            } else {
                $scope.searchPerspective = 'Favorites'
            }
            $scope.updateCombinedDomainReportList();
        };
        console.log('inside main controller');

        $rootScope.subtitle = '';
        $rootScope.startIntro = function(){
            introJs().start();
        }

        $scope.domain_selectors = {
            cboe_enabled: !$rootScope.disable_cboe,
            qe_enabled: true,
            fi_enabled: !$rootScope.disable_fi,
            opt_enabled: true,
            ta_enabled:  !$rootScope.disable_ta,
            tfce_enabled: !$rootScope.disable_tfce
        };

        $scope.repors_jsons = {
            cboe_reports_json: [],
            demo_reports_json: []
        };

        $scope.oneAtATime = true;
        $scope.all_reports_list = [];
        $rootScope.combined_domain_reports_list = [];

        var domain = $stateParams.domain || 'core';

        console.log('APR1: main controller, domain: ' + domain);
        $scope.alerts = [
            {type: 'danger', closable: 'true',
                msg: 'Redirected to MIRS Home. Access was denied for the page you were trying visit.', show: $rootScope.isAccessDenied}
        ];
        $scope.closeAlert = function(index) {
            $scope.alerts.splice(index, 1);
        };

        $http.get( 'domains/' + domain + '/reports.json').success(function (res) {
            $rootScope.accordionList = res;
            console.log($rootScope.allowedDomains)
            var selectedDomains =_.reject(res[0].links, function(o,key1){
                o.active = false;
                for(var i=0; i < $rootScope.allowedDomains.length;i++) {
                    if (o.domain == $rootScope.allowedDomains[i]) {
                        o.active = true;
                    }
                }
                return !o.active;
            })
            res[0].links = [];
            _.forEach(selectedDomains, function(o,key) {
                res[0].links.push(o);
            });
            console.log(res[0].links)
            var a = $rootScope.accordionList;
            for (var i = 0; i < a.length; i++) {
                for (var j = 0; j < a[i].links.length; j++) {
                    var rep = { id: a[i].links[j].id, title: a[i].links[j].id + ': ' + a[i].links[j].title + ' (' + a[i].header + ')',
                        shortname: a[i].links[j].shortname, domain: a[i].links[j].domain };
                    $scope.all_reports_list.push(rep);
                }
            }
        });

        $rootScope.selection_made = '';

        $rootScope.onSelectInSearch = function($item, $model, $label) {
            $rootScope.selection_made = $item;
            console.log('inside on select, redirecting to: /' + $item.domain + '/' + $item.id);
            $http.get( 'domains/' +  $item.domain + '/reports.json').success(function (res) {
                $rootScope.accordionList = res;
                var a = $rootScope.accordionList;
                for (var i = 0; i < a.length; i++) {
                    for (var j = 0; j < a[i].links.length; j++) {
                        var rep = { id: a[i].links[j].id, title: a[i].links[j].id + ': ' + a[i].links[j].title + ' (' + a[i].header + ')',
                            shortname: a[i].links[j].shortname, domain:a[i].links[j].domain };
                        $scope.all_reports_list.push(rep);
                    }
                };
                $location.path('/' + $item.domain + '/' + $item.id);
                console.log($rootScope.accordionList)
            });
        };

        $scope.report_id = $stateParams.id;
        $scope.current_report = undefined;

        console.log('MAR31: inside report main controller, updating title, current report id: ' + $scope.report_id );

        $scope.oneAtATime = true;
        $scope.all_reports_list = [];
        $scope.updateCombinedDomainReportList = function() {
            console.log( 'MAR31: working on combined report list... ');
            $rootScope.combined_domain_reports_list = [];
            if ($scope.searchPerspective === 'Reports') {
                $rootScope.combined_domain_reports_list = [];
                if($scope.domain_selectors.cboe_enabled) {
                    console.log( 'MAR31: adding CBOE reports... ');
                    $http.get( 'domains/cboe/reports.json').success(function (res) {
                        console.log('reading CBOE json')
                        console.log(res)
                        $scope.repors_jsons.cboe_reports_json = res;
                        var a = $scope.repors_jsons.cboe_reports_json;
                        for (var i = 0; i < a.length; i++) {
                            for (var j = 0; j < a[i].links.length; j++) {
                                var rep = { id: a[i].links[j].id, title: a[i].links[j].id + ': ' + a[i].links[j].title + ' (' + a[i].header + ')', shortname: a[i].links[j].id,domain:a[i].links[j].domain };
                                $rootScope.combined_domain_reports_list.push(rep);
                            }
                        }
                        console.log($rootScope.combined_domain_reports_list)
                    });
                }

                if($scope.domain_selectors.qe_enabled) {
                    console.log( 'MAR31: adding qe reports... ');
                    $http.get( 'domains/equities/reports.json').success(function (res) {
                        console.log('reading equities json')
                        $scope.repors_jsons.demo_reports_json = res;
                        var a = $scope.repors_jsons.demo_reports_json;
                        for (var i = 0; i < a.length; i++) {
                            for (var j = 0; j < a[i].links.length; j++) {
                                var rep = { id: a[i].links[j].id, title: a[i].links[j].id + ': ' + a[i].links[j].title + ' (' + a[i].header + ')', shortname: a[i].links[j].id,domain:a[i].links[j].domain };
                                $rootScope.combined_domain_reports_list.push(rep);
                            }
                        }
                    });
                }
                if($scope.domain_selectors.fi_enabled) {
                    console.log( 'MAR31: adding fi reports... ');
                    $http.get( 'domains/fi/reports.json').success(function (res) {
                        console.log('reading fi json')
                        $scope.repors_jsons.demo_reports_json = res;
                        var a = $scope.repors_jsons.demo_reports_json;
                        for (var i = 0; i < a.length; i++) {
                            for (var j = 0; j < a[i].links.length; j++) {
                                var rep = { id: a[i].links[j].id, title: a[i].links[j].id + ': ' + a[i].links[j].title + ' (' + a[i].header + ')', shortname: a[i].links[j].id,domain:a[i].links[j].domain };
                                $rootScope.combined_domain_reports_list.push(rep);
                            }
                        }
                    });
                }
                if($scope.domain_selectors.opt_enabled) {
                    console.log( 'MAR31: adding opt reports... ');
                    $http.get( 'domains/options/reports.json').success(function (res) {
                        console.log('reading options json')
                        $scope.repors_jsons.demo_reports_json = res;
                        var a = $scope.repors_jsons.demo_reports_json;
                        for (var i = 0; i < a.length; i++) {
                            for (var j = 0; j < a[i].links.length; j++) {
                                var rep = { id: a[i].links[j].id, title: a[i].links[j].id + ': ' + a[i].links[j].title + ' (' + a[i].header + ')', shortname: a[i].links[j].id,domain:a[i].links[j].domain };
                                $rootScope.combined_domain_reports_list.push(rep);
                            }
                        }
                    });
                }
                if($scope.domain_selectors.ta_enabled) {
                    console.log( 'MAR31: adding ta reports... ');
                    $http.get( 'domains/ta/reports.json').success(function (res) {
                        console.log('reading ta json')
                        $scope.repors_jsons.demo_reports_json = res;
                        var a = $scope.repors_jsons.demo_reports_json;
                        for (var i = 0; i < a.length; i++) {
                            for (var j = 0; j < a[i].links.length; j++) {
                                var rep = { id: a[i].links[j].id, title: a[i].links[j].id + ': ' + a[i].links[j].title + ' (' + a[i].header + ')', shortname: a[i].links[j].id,domain:a[i].links[j].domain };
                                $rootScope.combined_domain_reports_list.push(rep);
                            }
                        }
                    });
                }
                if($scope.domain_selectors.tfce_enabled) {
                    console.log( 'MAR31: adding tfce reports... ');
                    $http.get( 'domains/tfce/reports.json').success(function (res) {
                        console.log('reading tfce json')
                        $scope.repors_jsons.demo_reports_json = res;
                        var a = $scope.repors_jsons.demo_reports_json;
                        for (var i = 0; i < a.length; i++) {
                            for (var j = 0; j < a[i].links.length; j++) {
                                var rep = { id: a[i].links[j].id, title: a[i].links[j].id + ': ' + a[i].links[j].title + ' (' + a[i].header + ')', shortname: a[i].links[j].id,domain:a[i].links[j].domain };
                                $rootScope.combined_domain_reports_list.push(rep);
                            }
                        }
                    });
                }

                if (($scope.domain_selectors.cboe_enabled && $scope.domain_selectors.qe_enabled&&
                        $scope.domain_selectors.fi_enabled&& $scope.domain_selectors.opt_enabled&&
                        $scope.domain_selectors.ta_enabled&& $scope.domain_selectors.tfce_enabled
                    )=== false ) {
                    $http.get( 'domains/core/reports.json').success(function (res) {
                        console.log('reading core json')
                        $scope.repors_jsons.demo_reports_json = res;
                        var a = $scope.repors_jsons.demo_reports_json;
                        for (var i = 0; i < a.length; i++) {
                            for (var j = 0; j < a[i].links.length; j++) {
                                var rep = { id: a[i].links[j].id, title: a[i].links[j].id + ': ' + a[i].links[j].title + ' (' + a[i].header + ')', shortname: a[i].links[j].id,domain:a[i].links[j].domain };
                                $rootScope.combined_domain_reports_list.push(rep);
                            }
                        };
                    });

                }

            }
            if ($scope.searchPerspective === 'Recent') {
                $rootScope.combined_domain_reports_list = [];
                var hs = $rootScope.userInfo.info;
                console.log( hs[0].params_json)
                console.log(domain)
                for (var i = 0; i < hs.length; i++) {
                    var paramParsed = JSON.parse(hs[i].params_json);
                    var notParsed = hs[i].params_json;
                    var date = new Date(hs[i].subbmitted_ts);
                    var rep = {
                        id: hs[i].report_id,
                        title: 'Report Id--' + hs[i].report_id + 'Params--' + hs[i].params_json + ';Time submitted--' + date,
                        //title: hs[i].params_json,
                        params: JSON.parse(hs[i].params_json),
                        domain: (function () {
                            if (hs[i].domain_id == undefined) {
                                return 'cboe';
                            } else {return hs[i].domain_id}
                        })()
                    };
                    $rootScope.combined_domain_reports_list.push(rep);
                }
            }
        }

        $scope.domainSelectorsChangeCallback = function() {
            console.log( 'This is the state of DEMO ' + $scope.domain_selectors.demo_enabled );
            console.log( 'This is the state of CBOE ' + $scope.domain_selectors.cboe_enabled );

            //rebuild reports after changing domains
            $scope.updateCombinedDomainReportList();
        };
        $scope.updateCombinedDomainReportList();

    }); //main controller

    apps.app.controller('ReportController', function ($rootScope, $http, $scope, $localStorage, $stateParams) {

        console.log('inside report controller....');
        $rootScope.isHTMLformat = false;
        $rootScope.isFirstAnalyzerReport = false;
        $rootScope.isSecondAnalyzerReport = false;
        $rootScope.isThirdAnalyzerReport = false;
        $scope.report_id = $stateParams.id;
        console.log($scope);
        $scope.current_report = undefined;
        $scope.oneAtATime = true;
        $scope.all_reports_list = [];
        console.log($stateParams);
        $scope.selectedDomainHomePerspective = "Reports";
        if($scope.selectedDomainHomePerspective == 'Reports') {
            $http.get('domains/' + $stateParams.domain + '/reports.json').success(function (res) {
                $rootScope.accordionList = res;
                var a = $rootScope.accordionList;
                for (var i = 0; i < a.length; i++) {
                    for (var j = 0; j < a[i].links.length; j++) {
                        var rep = {
                            id: a[i].links[j].id,
                            title: a[i].links[j].id + ': ' + a[i].links[j].title + ' (' + a[i].header + ')',
                            shortname: domain + ':' + a[i].links[j].id,
                            domain: domain,
                            pentaho_url: a[i].links[j].pentaho_url,
                            subreports: a[i].links[j].subreports
                        };
                        $scope.all_reports_list.push(rep);
                        if (a[i].links[j].id === $stateParams.id) {
                            $scope.current_report = a[i].links[j]
                            $rootScope.current_report = $scope.current_report;
                            $rootScope.subtitle = a[i].header;
                        }
                    }
                }
                $rootScope.selection_made = "";
            });
            console.log($rootScope.accordionList)
            console.log($scope.all_reports_list);
        }

        $rootScope.onDomainHomePerspectiveChange = function(e) {
            if($scope.selectedDomainHomePerspective == 'Reports') {
                $scope.all_reports_list =[];
                $http.get('domains/' + $stateParams.domain + '/reports.json').success(function (res) {
                    $rootScope.accordionList = res;
                    var a = $rootScope.accordionList;
                    for (var i = 0; i < a.length; i++) {
                        for (var j = 0; j < a[i].links.length; j++) {
                            var rep = {
                                id: a[i].links[j].id,
                                title: a[i].links[j].id + ': ' + a[i].links[j].title + ' (' + a[i].header + ')',
                                shortname: domain + ':' + a[i].links[j].id,
                                domain: domain,
                                pentaho_url: a[i].links[j].pentaho_url,
                                subreports: a[i].links[j].subreports
                            };
                            $scope.all_reports_list.push(rep);
                            if (a[i].links[j].id === $stateParams.id) {
                                $scope.current_report = a[i].links[j]
                                $rootScope.current_report = $scope.current_report;
                                $rootScope.subtitle = a[i].header;
                            }
                        }
                    }
                    $rootScope.selection_made = "";
                });
                console.log($rootScope.accordionList)
                console.log($scope.all_reports_list);
            } else if ($scope.selectedDomainHomePerspective == 'Recent') {
                $rootScope.combined_domain_reports_list = [];
                $scope.all_reports_list =[];
                var hs = $rootScope.userInfo.info;
                console.log( hs[0].params_json)
                for (var i = 0; i < hs.length; i++) {
                    var paramParsed = JSON.parse(hs[i].params_json);
                    var notParsed = hs[i].params_json;
                    var date = new Date(hs[i].subbmitted_ts);
                    var rep = {
                        id: hs[i].report_id,
                        title: 'Report Id--' + hs[i].report_id + 'Params--' + hs[i].params_json + ';Time submitted--' + date,
                        //title: hs[i].params_json,
                        params: JSON.parse(hs[i].params_json),
                        domain: (function () {
                            if (hs[i].domain_id == undefined) {
                                return 'cboe';
                            } else {return hs[i].domain_id}
                        })()
                    };
                    $scope.all_reports_list.push(rep);
                }
            } else {
                $scope.searchPerspective = 'Favorites'
            }
            //$scope.updateCombinedDomainReportList();
        };

        //$scope.current_report = $rootScope.selection_made;

        var domain = $stateParams.domain || 'cboe';
        console.log('Inside REPORT controller, reloading reports.json for the domain: ' + domain);
    }); // end reportController

    apps.app.filter('toTrusted', ['$sce', function ($sce) {
        return function (text) {
            return $sce.trustAsHtml(text);
        };
    }]);

    apps.app.directive('dateLocator', cboeDirective.dateLocator);
    apps.app.directive('startDateLocator', cboeDirective.startDateLocator);
    apps.app.directive('endDateLocator', cboeDirective.endDateLocator);
    apps.app.directive('exprDateLocator', cboeDirective.exprDateLocator);
    apps.app.directive('exprStartDateLocator', cboeDirective.exprStartDateLocator);
    apps.app.directive('exprEndDateLocator', cboeDirective.exprEndDateLocator);
    apps.app.directive('classSymLocator', cboeDirective.classSymLocator);
    apps.app.directive('undlySymLocator', cboeDirective.undlySymLocator);
    apps.app.directive('multiSelectLocator', cboeDirective.multiSelectLocator);
    apps.app.directive('multiSelectLocatorExchange', cboeDirective.multiSelectLocatorExchange);
    apps.app.directive('radioButtonLocator', cboeDirective.radioButtonLocator);
    apps.app.directive('buySideBuyFirmLocator', cboeDirective.buySideBuyFirmLocator);
    apps.app.directive('sellSideBuyFirmLocator', cboeDirective.sellSideBuyFirmLocator);
    apps.app.directive('sellSideSellFirmLocator', cboeDirective.sellSideSellFirmLocator);
    apps.app.directive('buySideSellFirmLocator', cboeDirective.buySideSellFirmLocator);
    apps.app.directive('clearFirmLocator', cboeDirective.clearFirmLocator);
    apps.app.directive('clearFirmLocator2', cboeDirective.clearFirmLocator2);
    apps.app.directive('undlySymLocator2', cboeDirective.undlySymLocator2);
    apps.app.directive('iframeOnload', cboeDirective.iframeOnload);
    apps.app.directive('firmMultiSelectLocator', cboeDirective.firmMultiSelectLocator);
    apps.app.directive('rangeMultiSelectLocator', cboeDirective.rangeMultiSelectLocator);
    apps.app.directive('popoverDrct', cboeDirective.popoverDrct);

    //common controllers
    apps.app.controller('CollapseCtrl', cboe.CollapseCtrl);
    apps.app.controller('ResultCtrl', result.ResultCtrl);
    apps.app.controller('PaginationCtrl', cboe.PaginationCtrl);
    apps.app.controller('DatepickerAnglrMtrlCtrl', cboe.DatepickerAnglrMtrlCtrl);
    apps.app.controller('TypeAheadCtrl', cboe.TypeAheadCtrl);
    apps.app.controller('MultiSelectCtrl', cboe.MultiSelectCtrl);
    apps.app.controller('dlgHelpCtrl', mirs.dlgHelpCtrl);
    //apps.app.constant('apiUrl', 'http://mirs.int.finra.org/dblookup/cboe');
    apps.app.value('apiUrl', function(){
            if (location.hostname.indexOf('localhost') > -1)
                return location.protocol + "//" + location.hostname + ":9083/cboe";
            else
                return location.protocol + "//" + location.hostname + "/dblookup/cboe";
        }
    );

    apps.app.value('mirs_apiUrl', function(){
            if (location.hostname.indexOf('localhost') > -1)
                return location.protocol + "//" + location.hostname + ":9083/meta";
            else
                return location.protocol + "//" + location.hostname + "/dblookup/meta";
        }
    );

    apps.app.constant('userID','cboe_user');
    // apps.app.constant('mirs_apiUrl','http://mirs.int.finra.org/dblookup/meta');
    apps.app.factory('cboeApi', ['$http', 'apiUrl', 'userID', cboeApi]);

    return apps;
})();